# Bolso Retro 2.0 — execução nativa Libretro (alpha)

Esta versão substitui **EmulatorJS + WebView na execução** por **LibretroDroid + GLRetroView**, usando mGBA para Game Boy Advance e melonDS DS para Nintendo DS. A interface de biblioteca continua WebView + IndexedDB, preservando a estrutura visual do projeto anterior. Não há ROMs incluídas.

## Arquitetura

1. A biblioteca mostra os jogos gravados no IndexedDB do app (a mesma origem do APK anterior).
2. `app.js` envia o jogo para `native-bridge.js`, que lê o Blob em fatias (48 KiB) e as transfere via interface JavaScript local.
3. `MainActivity.java` recebe e grava a ROM na área privada do Android; se ZIP, extrai a ROM compatível com limite de tamanho.
4. `GameActivity.kt` recebe o caminho da ROM, prepara `GLRetroViewData` e inicia `GLRetroView` (renderização e áudio nativos).
5. Botões de toque e gamepads físicos geram eventos Libretro. No DS, o toque na tela da GLRetroView é encaminhado ao núcleo.
6. Estados salvos manualmente e SRAM ficam em `files/saves/` com identificadores distintos para cada jogo.

## Compilar no GitHub Actions

- Extraia **este projeto completo** e faça commit preservando as pastas (`app/`, `scripts/`, `.github/workflows/`). Não envie somente o ZIP esperando que o GitHub o extraia.
- A compilação usa JDK 17, Gradle 8.9, LibretroDroid via JitPack e núcleos Android ARM64 do buildbot Libretro.
- Os downloads de dependências e núcleos exigem internet **somente para a compilação**.
- A versão alvo é **Android ARM64**; aparelhos ARM32 não são suportados nesta alpha.
- Confira o artefato **BolsoRetro-Nativo-2.0** em Actions após compilação verde.

### Se o GitHub receber todos os arquivos na raiz

O upload pelo navegador às vezes perde pastas. Recomenda-se extrair localmente e fazer `git add -A`, `git commit`, `git push` com Git instalado. O workflow precisa estar em `.github/workflows/build-apk.yml` e a classe nativa em `app/src/main/java/br/com/bolsoretro/GameActivity.kt`.

## Limitações e testes obrigatórios

- **Ainda não foi compilado nem validado em aparelho físico neste ambiente**. Esta é uma integração de código cuja versão Android precisa ser compilada e testada no GitHub antes de se declarar funcional.
- A dependência JitPack e os endereços dos núcleos podem mudar; CI falhará explicitamente se indisponíveis.
- O núcleo melonDS DS pode exigir firmware/BIOS legalmente obtidos para certos jogos, e suporte a dual screen depende das opções do núcleo. Verifique especificamente *Pokémon HeartGold*.
- Salvamentos do EmulatorJS não são automaticamente convertidos para estados/arquivos Libretro.
- Esta versão mantém o mesmo applicationId `br.com.bolsoretro`, mas compilação com chave debug diferente pode impedir instalar sobre o APK anterior. Faça backup das ROMs/saves antes de desinstalar.
- Bluetooth é encaminhado para LibretroDroid, ainda não testado em dispositivo.
- Núcleos instalados no APK; não requer CDN ou internet para carregar a ROM após instalado.

## Licenças

O LibretroDroid e Lemuroid usam **GPL-3.0**, portanto qualquer redistribuição com componentes GPL deve preservar licenças, atribuição e acesso ao código-fonte correspondente. Veja `THIRD_PARTY.md` e `LICENSE-GPL-3.0.txt`. Esta adaptação utiliza LibretroDroid como dependência; não é um clone literal do código do Lemuroid.
