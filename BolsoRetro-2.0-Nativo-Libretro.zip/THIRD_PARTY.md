# Atribuições e licenças

- **LibretroDroid** — Filippo Scognamiglio / Swordfish90, GPL-3.0-or-later, https://github.com/Swordfish90/LibretroDroid
- **Lemuroid** — projeto de referência de arquitetura, GPL-3.0-or-later, https://github.com/Swordfish90/Lemuroid. Não inclui o código-fonte integral do Lemuroid.
- **mGBA** — https://github.com/mgba-emu/mgba. Verifique a licença do núcleo distribuído.
- **melonDS DS (Libretro)** — https://github.com/libretro/melonDS-DS. Verifique a licença do núcleo distribuído.

A distribuição binária do aplicativo com componentes GPL exige cumprimento da GPL e fornecimento do código-fonte correspondente. Este repositório disponibiliza o código do frontend, mas depende de bibliotecas nativas obtidas durante a compilação. Mantenha instruções de reconstrução, versões e avisos de copyright e licenças do conjunto de núcleos. Não inclua ROMs comerciais ou BIOS protegidas.

- **PCSX ReARMed (PS1)** — https://github.com/notaz/pcsx_rearmed, GPLv2, núcleo libretro.
- **PPSSPP (PSP)** — https://github.com/hrydgard/ppsspp, GPLv2, núcleo libretro e assets do sistema.
- `PPSSPP.zip` obtido do buildbot libretro durante a compilação. Verificar obrigações de redistribuição de seus componentes.
- PS2 não incluído. Sem ROMs ou BIOS comerciais.
