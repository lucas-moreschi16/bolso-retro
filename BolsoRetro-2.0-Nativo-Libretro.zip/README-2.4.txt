BOLSO RETRO 2.4 — Correção GitHub + PS1/PSP + PS2 experimental + ↶20

1. GBA/DS: a área de controles GBA volta a utilizar o painel do DS que estava funcionando. O processamento nativo de ROMs foi preservado.
2. PS1: PCSX ReARMed; PSP: PPSSPP, incorporados pelo download_cores.sh, com suporte experimental já existente.
3. PS2: Play! Libretro Android ARM64 (experimental). Requer OpenGL ES 3.2; a disponibilidade do núcleo não garante jogos funcionais.
4. ↶20: estados automáticos a cada 2,5 s, até 96 MiB RAM, usando serializeState/unserializeState. Apenas GBA, DS e PS1, sujeito ao suporte do núcleo. Ainda não é retrocesso contínuo; aproxima 20 s reais em velocidade normal. Incompatível com PSP/PS2. Estados ficam só em RAM e somem ao fechar o app.
5. PS2 aceita arquivos ISO/CHD/CSO/ISZ até 12 GB; a cópia usa o armazenamento do aparelho. Não inclui BIOS ou ROMs.
6. Atenção: compilação bem-sucedida não garante estabilidade Android. O APK necessita de testes reais. Preserve salvamentos e evite desinstalar versões antigas.
7. O ZIP contém o código, não um APK. Substitua BolsoRetro-2.0-Nativo-Libretro.zip na RAIZ do GitHub pelo ZIP com o mesmo nome. O workflow existente extrai o ZIP e inicia o build.
8. Se ocorrer nova falha na etapa de extração, verifique o nome EXATO no repositório. ZIP extra não muda o workflow dentro de .github automaticamente.

Licenças: veja LICENSE-GPL-3.0.txt e THIRD_PARTY.md. ROMs e BIOS comerciais não incluídas.
