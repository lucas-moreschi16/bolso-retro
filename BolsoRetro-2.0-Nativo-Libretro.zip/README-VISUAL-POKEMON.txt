BOLSO RETRO — EDIÇÃO PESSOAL POKÉMON

Biblioteca temática de floresta ao entardecer com Chikorita, Psyduck e Vulpix.
Não modifica os núcleos nativos nem os layouts dos controles (GBA / DS).
Arquivos criados em app/src/main/assets:
- pokemon-trio-banner.jpg (ilustração da capa)
- pokemon-forest-blur.jpg (detalhe da tela de continuar)
- icons/icon-192.png e icon-512.png (ícones temáticos)
Ícone do Android: app/src/main/res/drawable/app_icon.png

O material é uma criação de fã para uso pessoal, não oficial e sem afiliação
com Nintendo, Game Freak, Creatures Inc. ou The Pokémon Company.
Nenhum jogo, firmware ou ROM foi incluído.

O projeto também mantém as alterações experimentais da versão 2.4
(PS1/PSP/PS2 beta e ↶20 segundos), ainda não validadas em aparelho.

ZIP de compilação: enviar com o nome exato BolsoRetro-2.0-Nativo-Libretro.zip
O workflow deve ser atualizado SEPARADAMENTE no GitHub.
