package br.com.bolsoretro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.database.Cursor;
import android.provider.OpenableColumns;
import org.json.JSONObject;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int PICK = 19;
    private static final int PICK_DISC = 20;
    private static final int PICK_PS1_BIOS = 21;
    private static final long MAX_DISC = 5L * 1024 * 1024 * 1024;
    private String pickedPlatform = null;
    private static final long MAX_ROM = 512L * 1024 * 1024;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private final Object transferLock = new Object();
    private ValueCallback<Uri[]> fileCallback;
    private WebView browser;
    private File tmp;
    private FileOutputStream pending;
    private long count;
    private long expected;
    private String coreSystem;
    private String safeID;
    private String gameName;
    private String extension;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,16,29));
        getWindow().setNavigationBarColor(Color.rgb(10,16,29));
        browser = new WebView(this);
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest r) {
                return assetLoader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                return !APP_ORIGIN.equals(u.getScheme()+"://"+u.getHost());
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                   FileChooserParams params) {
                if(fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try {startActivityForResult(pick,PICK);return true;}
                catch(Exception ex) {fileCallback=null;callback.onReceiveValue(null);return false;}
            }
        });
        browser.addJavascriptInterface(new Bridge(),"BolsoAndroid");
        setContentView(browser);
        browser.loadUrl(APP_ORIGIN + "/assets/index.html");
    }
    private void emitJs(String func,String value) {
        String quoted=JSONObject.quote(value == null ? "" : value);
        runOnUiThread(() -> {
            if(browser != null) browser.evaluateJavascript("window."+func+" && window."+func+"("+quoted+")",null);
        });
    }
    private String fileName(Uri uri) {
        try (Cursor cursor=getContentResolver().query(uri,null,null,null,null)) {
            if(cursor != null && cursor.moveToFirst()) {
                int index=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(index>=0 && !cursor.isNull(index))return cursor.getString(index);
            }
        } catch(Exception ignored) {}
        return uri.getLastPathSegment()==null ? "disco" : uri.getLastPathSegment();
    }
    private long fileSize(Uri uri) {
        try (Cursor cursor=getContentResolver().query(uri,null,null,null,null)) {
            if(cursor != null && cursor.moveToFirst()) {
                int index=cursor.getColumnIndex(OpenableColumns.SIZE);
                if(index>=0 && !cursor.isNull(index))return cursor.getLong(index);
            }
        } catch(Exception ignored) {}
        return 0;
    }
    private static boolean validDisc(String system,String name) {
        String ext=name.toLowerCase(Locale.US);
        if("ps1".equals(system)) return ext.endsWith(".chd")||ext.endsWith(".pbp")||ext.endsWith(".bin")||ext.endsWith(".img")||ext.endsWith(".iso");
        if("psp".equals(system)) return ext.endsWith(".iso")||ext.endsWith(".cso")||ext.endsWith(".chd")||ext.endsWith(".pbp");
        return false;
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==PICK_DISC) {
            if(result==RESULT_OK && data!=null && data.getData()!=null && pickedPlatform!=null) {
                Uri uri=data.getData();
                try {
                    String name=fileName(uri);
                    if(!validDisc(pickedPlatform,name))throw new IOException("Formato não aceito. PS1: CHD/PBP/BIN/IMG/ISO; PSP: ISO/CSO/CHD/PBP. CUE com trilhas externas não é suportado.");
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    JSONObject json=new JSONObject();
                    json.put("system",pickedPlatform);json.put("name",name);
                    json.put("uri",uri.toString());json.put("size",fileSize(uri));
                    emitDiscObject(json.toString());
                } catch(Exception e){emitJs("BolsoDiscImportError",e.getMessage());}
            }
            pickedPlatform=null;
            return;
        }
        if(req==PICK_PS1_BIOS) {
            if(result==RESULT_OK && data!=null && data.getData()!=null) {
                Uri uri=data.getData();
                String name=fileName(uri).toLowerCase(Locale.US);
                if(!name.matches("scph[0-9]{4,5}\\.bin")) {emitJs("BolsoDiscImportError","Nome de BIOS inesperado: use scph5501.bin, scph5502.bin etc.");return;}
                try {
                    File dir=new File(getFilesDir(),"system");dir.mkdirs();
                    File dest=new File(dir,name);
                    try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(dest)) {
                        if(in==null)throw new IOException("BIOS ilegível");
                        byte[] bytes=new byte[16384];long count=0;int n;
                        while((n=in.read(bytes))!=-1){count+=n;if(count>2_000_000)throw new IOException("Arquivo BIOS excessivamente grande");out.write(bytes,0,n);}
                    }
                    emitJs("BolsoDiscStatus","BIOS própria de PS1 importada com sucesso.");
                }catch(Exception e){emitJs("BolsoDiscImportError",e.getMessage());}
            }
            return;
        }
        if(req != PICK || fileCallback == null) return;
        Uri[] uris=null;
        if(result == RESULT_OK && data != null) {
            if(data.getClipData()!=null) {
                int n=data.getClipData().getItemCount(); uris=new Uri[n];
                for(int i=0;i<n;i++) uris[i]=data.getClipData().getItemAt(i).getUri();
            } else if(data.getData()!=null) uris=new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(uris); fileCallback=null;
    }
    private void emitDiscObject(String json) {
        runOnUiThread(() -> {if(browser!=null)browser.evaluateJavascript("window.BolsoDiscImported && window.BolsoDiscImported("+json+")",null);});
    }
    private void openDocument(int request) {
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {startActivityForResult(intent,request);}catch(Exception e){emitJs("BolsoDiscImportError",e.getMessage());}
    }
    private void abortTransfer() {
        try {if(pending!=null)pending.close();}catch(Exception ignore){}
        pending=null;
        if(tmp!=null)tmp.delete();
        tmp=null;count=0;expected=0;
    }
    private static String shortHash(String s) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
        StringBuilder out=new StringBuilder();
        for(int i=0;i<8;i++)out.append(String.format(Locale.US,"%02x",digest[i]&255));
        return out.toString();
    }
    public class Bridge {
        @JavascriptInterface public void pickDisc(String system) {
            if(!("ps1".equals(system)||"psp".equals(system)))return;
            runOnUiThread(()->{pickedPlatform=system;openDocument(PICK_DISC);});
        }
        @JavascriptInterface public void pickBios() {runOnUiThread(()->openDocument(PICK_PS1_BIOS));}
        @JavascriptInterface public String openDisc(String uriText,String system,String id,String title,String fileName) {
            if(!validDisc(system,fileName))return "Formato de disco inválido";
            try {
                Uri uri=Uri.parse(uriText);
                if(!"content".equals(uri.getScheme()))return "Endereço de disco inválido";
                String safe=shortHash(system+"/"+id+"/"+title);
                new Thread(()->{
                    File outFile=null;
                    try {
                        String suffix=fileName.substring(fileName.lastIndexOf('.')).toLowerCase(Locale.US);
                        File folder=new File(getCacheDir(),"discs");folder.mkdirs();
                        outFile=new File(folder,safe+suffix);
                        long known=fileSize(uri);
                        if(known>MAX_DISC)throw new IOException("Disco acima do limite de 5 GB");
                        if(!outFile.isFile()||outFile.length()==0||known>0&&outFile.length()!=known) {
                            emitJs("BolsoDiscStatus","Copiando disco para cache local. Aguarde…");
                            File partial=new File(folder,safe+suffix+".part");
                            try(InputStream in=getContentResolver().openInputStream(uri); OutputStream output=new FileOutputStream(partial)) {
                                if(in==null)throw new IOException("Permissão de acesso perdida. Reimporte o disco.");
                                byte[] buf=new byte[256*1024];int n;long total=0;int lastPercent=-1;
                                while((n=in.read(buf))!=-1){total+=n;if(total>MAX_DISC)throw new IOException("Disco acima do limite de 5 GB");output.write(buf,0,n);
                                  int percent=known>0?(int)(100*total/known):0;
                                  if(known>0&&percent/10>lastPercent/10) {lastPercent=percent;emitJs("BolsoDiscStatus","Preparando "+system.toUpperCase(Locale.US)+": "+percent+"%");}
                                }
                            }
                            if(partial.length()==0)throw new IOException("Arquivo vazio");
                            if(outFile.exists())outFile.delete();
                            if(!partial.renameTo(outFile))throw new IOException("Não foi possível preparar o cache");
                        }
                        File rom=outFile;
                        runOnUiThread(()->{
                            Intent intent=new Intent(MainActivity.this,GameActivity.class);
                            intent.putExtra("rom",rom.getAbsolutePath());intent.putExtra("system",system);
                            intent.putExtra("gameName",title);intent.putExtra("saveId",safe);
                            startActivity(intent);
                        });
                    } catch(Exception e){
                        emitJs("BolsoDiscImportError","Não foi possível abrir o disco: "+e.getMessage());
                    }
                }, "bolsoretro-disc-reader").start();
                return "OK";
            } catch(Exception ex){return ex.getMessage();}
        }
        @JavascriptInterface public String begin(String system,String id,String title,String ext,String length) {
            synchronized(transferLock) {
                abortTransfer();
                if(!("gba".equals(system)||"nds".equals(system)))return "Sistema não suportado";
                if(!("gba".equals(ext)||"nds".equals(ext)||"zip".equals(ext)))return "Formato inválido";
                try {
                    long size=Long.parseLong(length);
                    if(size<=0||size>MAX_ROM)return "ROM acima do limite de 512 MB";
                    String safe = shortHash(system+"/"+id+"/"+title);
                    File directory = new File(getCacheDir(),"import");
                    if(!directory.exists()&&!directory.mkdirs())return "Falha ao preparar diretório";
                    tmp=new File(directory,safe+".part");
                    pending=new FileOutputStream(tmp,false);
                    expected=size;count=0;coreSystem=system;extension=ext;safeID=safe;gameName=title;
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Falha: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String chunk(String encoded) {
            synchronized(transferLock) {
                if(pending==null)return "Transferência não iniciada";
                try {
                    byte[] buf=Base64.decode(encoded,Base64.NO_WRAP);
                    if(count+buf.length>expected)throw new IOException("ROM maior que o informado");
                    pending.write(buf);count+=buf.length;
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Falha na transferência: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String finish() {
            synchronized(transferLock) {
                if(pending==null||count!=expected)return "ROM incompleta";
                try {
                    pending.close();pending=null;
                    File rom=new File(getCacheDir(),"bolso-game-"+safeID+"."+coreSystem);
                    if("zip".equals(extension)) {
                        try(ZipInputStream zip=new ZipInputStream(new FileInputStream(tmp));
                            FileOutputStream output=new FileOutputStream(rom,false)) {
                            ZipEntry z;boolean found=false;
                            while((z=zip.getNextEntry())!=null) {
                                if(z.isDirectory()||!z.getName().toLowerCase(Locale.US).endsWith("."+coreSystem))continue;
                                byte[] buff=new byte[65536];int n;long extracted=0;
                                while((n=zip.read(buff))!=-1) {
                                    extracted+=n;
                                    if(extracted>MAX_ROM)throw new IOException("ROM descompactada acima de 512 MB");
                                    output.write(buff,0,n);
                                }
                                found=true;break;
                            }
                            if(!found)throw new IOException("ZIP sem ROM ."+coreSystem);
                        }
                        tmp.delete();
                    } else {
                        if(!tmp.renameTo(rom))Files.copy(tmp.toPath(),rom.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        tmp.delete();
                    }
                    if(!rom.exists()||rom.length()==0)throw new IOException("Arquivo vazio");
                    String sys=coreSystem, title=gameName, saveId=safeID;
                    tmp=null;
                    runOnUiThread(()->{
                        Intent intent=new Intent(MainActivity.this,GameActivity.class);
                        intent.putExtra("rom",rom.getAbsolutePath());intent.putExtra("system",sys);
                        intent.putExtra("gameName",title);intent.putExtra("saveId",saveId);
                        startActivity(intent);
                    });
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Não foi possível abrir ROM: "+e.getMessage();}
            }
        }
        @JavascriptInterface public void cancel(){synchronized(transferLock){abortTransfer();}}
    }
    @Override protected void onDestroy(){
        synchronized(transferLock){abortTransfer();}
        if(browser!=null)browser.destroy();
        super.onDestroy();
    }
}
