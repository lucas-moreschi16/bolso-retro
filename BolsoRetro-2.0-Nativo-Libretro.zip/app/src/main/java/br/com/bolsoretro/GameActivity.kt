/*
 * Bolso Retro - interface nativa para LibretroDroid.
 * A biblioteca LibretroDroid e codigo de terceiros licenciado em GPL-3.0.
 * Copyright (C) 2026 Bolso Retro contributors. SPDX-License-Identifier: GPL-3.0-or-later
 */
package br.com.bolsoretro

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File

class GameActivity : ComponentActivity() {
    private lateinit var retro: GLRetroView
    private lateinit var saveDir: File
    private lateinit var system: String
    private var started = false

    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(22, 30, 52)
    private val ink = Color.rgb(236, 238, 251)
    private val accent = Color.rgb(140, 122, 245)

    private fun dp(v: Int) = (resources.displayMetrics.density * v).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        system = intent.getStringExtra("system") ?: ""
        val rom = intent.getStringExtra("rom")?.let(::File)
        if (system !in setOf("gba", "nds") || rom == null || !rom.isFile || rom.length() == 0L) {
            Toast.makeText(this, "ROM inválida ou ausente", Toast.LENGTH_LONG).show()
            finish(); return
        }
        val saveId = intent.getStringExtra("saveId") ?: "sem-id"
        saveDir = File(filesDir, "saves/$saveId").apply { mkdirs() }
        val core = if (system == "gba") "libmgba_libretro_android.so" else "libmelondsds_libretro_android.so"
        try {
            val configured = GLRetroViewData(this).apply {
                coreFilePath = core
                gameFilePath = rom.absolutePath
                systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
                savesDirectory = saveDir.absolutePath
                shader = ShaderConfig.Default
                preferLowLatencyAudio = true
                rumbleEventsEnabled = false
                saveRAMState = File(saveDir, "battery.srm").takeIf { it.isFile }?.readBytes()
            }
            retro = GLRetroView(this, configured)
            buildInterface(intent.getStringExtra("gameName") ?: "Bolso Retro")
            lifecycle.addObserver(retro)
            started = true
            lifecycleScope.launch {
                retro.getGLRetroErrors().collect { err ->
                    Toast.makeText(this@GameActivity, "Falha no núcleo Libretro (código $err). Confira o jogo e o motor nativo.", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Falha ao abrir núcleo nativo: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun text(label: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = label; setTextColor(ink); textSize = size
        gravity = Gravity.CENTER_VERTICAL
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(ink); textSize = 12f
        backgroundTintList = ColorStateList.valueOf(panel)
        setOnClickListener { onClick() }
        minimumHeight = dp(44)
    }

    private fun addToRow(row: LinearLayout, child: View, weight: Float = 1f) {
        row.addView(child, LinearLayout.LayoutParams(0, dp(48), weight).apply {
            marginStart = dp(2); marginEnd = dp(2)
        })
    }

    private fun touchButton(label: String, key: Int) = Button(this).apply {
        text = label; isAllCaps = false
        setTextColor(ink)
        textSize = if(label.length > 3) 10f else 16f
        setPadding(0, 0, 0, 0)
        backgroundTintList = ColorStateList.valueOf(if(label == "A" || label == "B") accent else panel)
        // DOWN/UP: eventos contínuos, não apenas clique; adequados a movimento e comandos.
        setOnTouchListener { _, event ->
            val action = when(event.actionMasked) {
                MotionEvent.ACTION_DOWN -> KeyEvent.ACTION_DOWN
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> KeyEvent.ACTION_UP
                else -> return@setOnTouchListener true
            }
            retro.sendKeyEvent(action, key)
            true
        }
    }

    private fun buildInterface(title: String) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(root)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(dp(7), dp(2), dp(7), dp(2)) })
        val back = button("‹ Voltar") { finish() }
        header.addView(back, LinearLayout.LayoutParams(dp(90), dp(48)))
        val titleView = text(title, 14f, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        header.addView(titleView, LinearLayout.LayoutParams(0, -1, 1f))
        val save = button("Salvar") { saveState() }
        header.addView(save, LinearLayout.LayoutParams(dp(72), dp(48)))
        val load = button("Carregar") { loadState() }
        header.addView(load, LinearLayout.LayoutParams(dp(85), dp(48)))

        // Superfície OpenGL nativa: substitui o antigo elemento HTML/EmulatorJS.
        val surface = FrameLayout(this).apply {setBackgroundColor(Color.BLACK)}
        root.addView(surface, LinearLayout.LayoutParams(-1, 0, 1f))
        surface.addView(retro, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        if (system == "nds") {
            root.addView(text("DS: toque na tela inferior. Altere a posição das telas pelas opções do núcleo.", 11f).apply {
                gravity = Gravity.CENTER; setTextColor(Color.rgb(169, 177, 203))
            }, LinearLayout.LayoutParams(-1, dp(26)))
        }
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),dp(8),dp(8),dp(18)) }
        root.addView(pad, LinearLayout.LayoutParams(-1, -2))
        val shoulder = LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
        pad.addView(shoulder)
        addToRow(shoulder,touchButton("L",KeyEvent.KEYCODE_BUTTON_L1))
        addToRow(shoulder,touchButton("SELECT",KeyEvent.KEYCODE_BUTTON_SELECT))
        addToRow(shoulder,touchButton("START",KeyEvent.KEYCODE_BUTTON_START))
        addToRow(shoulder,touchButton("R",KeyEvent.KEYCODE_BUTTON_R1))
        val row = LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
        pad.addView(row)
        val dpad = LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        row.addView(dpad, LinearLayout.LayoutParams(0, -2, 1f))
        val dUp = LinearLayout(this); dpad.addView(dUp)
        addToRow(dUp, touchButton("↖",KeyEvent.KEYCODE_DPAD_UP_LEFT))
        addToRow(dUp, touchButton("↑",KeyEvent.KEYCODE_DPAD_UP))
        addToRow(dUp, touchButton("↗",KeyEvent.KEYCODE_DPAD_UP_RIGHT))
        val dMid = LinearLayout(this); dpad.addView(dMid)
        addToRow(dMid, touchButton("←",KeyEvent.KEYCODE_DPAD_LEFT))
        addToRow(dMid, text("+",26f,true).apply {gravity=Gravity.CENTER})
        addToRow(dMid, touchButton("→",KeyEvent.KEYCODE_DPAD_RIGHT))
        val dDown = LinearLayout(this); dpad.addView(dDown)
        addToRow(dDown, touchButton("↙",KeyEvent.KEYCODE_DPAD_DOWN_LEFT))
        addToRow(dDown, touchButton("↓",KeyEvent.KEYCODE_DPAD_DOWN))
        addToRow(dDown, touchButton("↘",KeyEvent.KEYCODE_DPAD_DOWN_RIGHT))
        val actions = LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        row.addView(actions,LinearLayout.LayoutParams(0, -2, 1f))
        val top = LinearLayout(this); actions.addView(top)
        if(system=="nds") addToRow(top,touchButton("X", KeyEvent.KEYCODE_BUTTON_X))
        else addToRow(top,text("",14f))
        addToRow(top,touchButton("A",KeyEvent.KEYCODE_BUTTON_A))
        val bottom = LinearLayout(this); actions.addView(bottom)
        addToRow(bottom,touchButton("B",KeyEvent.KEYCODE_BUTTON_B))
        if(system=="nds") addToRow(bottom,touchButton("Y",KeyEvent.KEYCODE_BUTTON_Y))
        else addToRow(bottom,text("",14f))
    }

    private fun saveSram() {
        if(!started) return
        try { File(saveDir,"battery.srm").writeBytes(retro.serializeSRAM()) }
        catch(e: Exception) { android.util.Log.w("BolsoRetro","Falha ao salvar SRAM",e) }
    }
    private fun saveState() {
        if (!started) return
        try {
            File(saveDir,"manual.state").writeBytes(retro.serializeState())
            saveSram()
            Toast.makeText(this,"Estado salvo",Toast.LENGTH_SHORT).show()
        } catch(e: Exception){Toast.makeText(this,"Erro ao salvar: ${e.message}",Toast.LENGTH_LONG).show()}
    }
    private fun loadState() {
        if(!started) return
        try {
            val f=File(saveDir,"manual.state")
            if(!f.exists()) {Toast.makeText(this,"Nenhum estado salvo",Toast.LENGTH_SHORT).show();return}
            val success=retro.unserializeState(f.readBytes())
            Toast.makeText(this,if(success)"Estado carregado" else "Estado incompatível",Toast.LENGTH_SHORT).show()
        }catch(e:Exception){Toast.makeText(this,"Erro ao carregar: ${e.message}",Toast.LENGTH_LONG).show()}
    }
    override fun onPause() {
        saveSram()
        super.onPause()
    }
    override fun onKeyDown(keyCode:Int, event:KeyEvent):Boolean {
        if(started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_DOWN,keyCode);return true
        }
        return super.onKeyDown(keyCode,event)
    }
    override fun onKeyUp(keyCode:Int,event:KeyEvent):Boolean {
        if(started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_UP,keyCode);return true
        }
        return super.onKeyUp(keyCode,event)
    }
    override fun onGenericMotionEvent(event:MotionEvent):Boolean {
        if(started && event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) {
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD,event.getAxisValue(MotionEvent.AXIS_HAT_X),event.getAxisValue(MotionEvent.AXIS_HAT_Y))
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT,event.getAxisValue(MotionEvent.AXIS_X),event.getAxisValue(MotionEvent.AXIS_Y))
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
