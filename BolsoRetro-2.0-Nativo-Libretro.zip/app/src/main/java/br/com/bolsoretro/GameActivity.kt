/*
 * Bolso Retro - Android native Libretro player.
 * The LibretroDroid dependency is provided by its authors under GPL-3.0.
 * Copyright (C) 2026 Bolso Retro contributors. SPDX-License-Identifier: GPL-3.0-or-later
 */
package br.com.bolsoretro

import android.content.res.Configuration
import android.app.ActivityManager
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.Variable
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.ArrayDeque
import java.util.zip.ZipInputStream

/**
 * Changes in orientation are handled inside this same Activity instance.
 * The GLRetroView and its loaded Libretro core are never removed/recreated on rotation.
 */
class GameActivity : ComponentActivity() {
    private lateinit var retro: GLRetroView
    private lateinit var saveDir: File
    private lateinit var system: String
    private lateinit var root: FrameLayout
    private lateinit var gameRegion: FrameLayout
    private lateinit var overlay: FrameLayout
    private lateinit var leftControls: LinearLayout
    private lateinit var rightControls: LinearLayout
    // GBA uses a dedicated action-button layer above the native GL surface.
    // Its independent bounds prevent the face buttons from vanishing when the
    // player is resized or Android changes orientation.
    // GBA uses the SAME known-working overlay layout as Nintendo DS.
    private var gbaActionLayer: FrameLayout? = null
    private lateinit var toolbar: LinearLayout
    private lateinit var speedButton: Button
    private lateinit var compactMenu: Button
    private var menuExpanded = true
    private lateinit var titleLabel: TextView
    private var speedIndex = 0
    private var speedAlternate = false
    private val speedHandler = Handler(Looper.getMainLooper())
    private data class Checkpoint(val at: Long, val bytes: ByteArray)
    private val checkpoints = ArrayDeque<Checkpoint>()
    private val snapshotBusy = AtomicBoolean(false)
    private var checkpointBytes = 0L
    private var snapshotFailures = 0
    private val maxCheckpointBytes = 96L * 1024 * 1024
    private val rewindHandler = Handler(Looper.getMainLooper())
    private val rewindTick = object : Runnable {
        override fun run() {
            if (!started || isFinishing || isDestroyed) return
            if (system !in setOf("gba", "nds", "ps1")) return
            if (snapshotFailures >= 2) return
            if (snapshotBusy.compareAndSet(false, true)) {
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        val bytes = retro.serializeState()
                        if (bytes.isEmpty() || bytes.size > 40 * 1024 * 1024) {
                            throw IllegalStateException("Estado grande ou indisponível")
                        }
                        synchronized(checkpoints) {
                            checkpoints.addLast(Checkpoint(SystemClock.elapsedRealtime(), bytes))
                            checkpointBytes += bytes.size.toLong()
                            while (checkpoints.size > 14 || checkpointBytes > maxCheckpointBytes) {
                                checkpointBytes -= checkpoints.removeFirst().bytes.size.toLong()
                            }
                        }
                    } catch (e: Exception) {
                        snapshotFailures++
                        Log.w("BolsoRetro", "Snapshot de retrocesso indisponível", e)
                    } finally { snapshotBusy.set(false) }
                }
            }
            rewindHandler.postDelayed(this, 2500L)
        }
    }

    /** Automatic checkpoints are transient; manual saves remain unchanged. */
    private fun rewindTwentySeconds() {
        if (!started) return
        if (system == "ps2" || system == "psp") {
            Toast.makeText(this, "Retrocesso indisponível neste núcleo", Toast.LENGTH_SHORT).show()
            return
        }
        if (!snapshotBusy.compareAndSet(false, true)) {
            Toast.makeText(this, "Aguarde concluir o estado atual", Toast.LENGTH_SHORT).show()
            return
        }
        val target = SystemClock.elapsedRealtime() - 20_000L
        val selected = synchronized(checkpoints) {
            checkpoints.lastOrNull { it.at <= target }
        }
        if (selected == null) {
            snapshotBusy.set(false)
            Toast.makeText(this, "Ainda não há 20 segundos de histórico", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val restored = retro.unserializeState(selected.bytes)
                if (restored) {
                    synchronized(checkpoints) {
                        while (checkpoints.isNotEmpty() && checkpoints.last().at > selected.at) {
                            checkpointBytes -= checkpoints.removeLast().bytes.size.toLong()
                        }
                    }
                }
                runOnUiThread {
                    Toast.makeText(this@GameActivity,
                        if (restored) "↶ Retrocesso de aproximadamente 20 s" else "Núcleo rejeitou o estado anterior",
                        Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("BolsoRetro", "Falha ao voltar 20s", e)
                runOnUiThread { Toast.makeText(this@GameActivity, "Falha ao retroceder: ${e.message}", Toast.LENGTH_LONG).show() }
            } finally { snapshotBusy.set(false) }
        }
    }
    private val speedCycle = object : Runnable {
        override fun run() {
            if (!started || speedIndex != 1) return
            // LibretroDroid supports integral frameSpeed values. Alternating 1 and 2
            // approximates 1.5x without patching its GPL native library.
            speedAlternate = !speedAlternate
            retro.frameSpeed = if (speedAlternate) 2 else 1
            speedHandler.postDelayed(this, 120L)
        }
    }
    private var started = false
    private var controlsVisible = true
    private var opacity = 0.42f
    private val controlButtons = mutableListOf<Pair<Button, Boolean>>()
    private val shoulderControls = mutableListOf<View>()
    private val bg = Color.rgb(7, 11, 20)
    private val ink = Color.rgb(247, 248, 255)
    private val accent = Color.rgb(132, 116, 245)

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + .5f).toInt()
    private fun landscape() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        system = intent.getStringExtra("system") ?: ""
        val rom = intent.getStringExtra("rom")?.let(::File)
        if (system !in setOf("gba", "nds", "ps1", "psp", "ps2") || rom == null || !rom.isFile || rom.length() <= 0) {
            Toast.makeText(this, "ROM inválida ou ausente", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        opacity = getPreferences(MODE_PRIVATE).getFloat("controlOpacity", .42f).coerceIn(.22f, .85f)
        controlsVisible = getPreferences(MODE_PRIVATE).getBoolean("controlsVisible", true)
        saveDir = File(filesDir, "saves/${intent.getStringExtra("saveId") ?: "sem-id"}").apply { mkdirs() }
        val core = when (system) {
            "gba" -> "libmgba_libretro_android.so"
            "nds" -> "libmelondsds_libretro_android.so"
            "ps1" -> "libpcsx_rearmed_libretro_android.so"
            "psp" -> "libppsspp_libretro_android.so"
            "ps2" -> "libplay_libretro_android.so"
            else -> error("Sistema desconhecido")
        }
        if (system == "ps2") {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            if (am.deviceConfigurationInfo.reqGlEsVersion < 0x00030002) {
                Toast.makeText(this, "PS2 experimental: é necessário OpenGL ES 3.2", Toast.LENGTH_LONG).show()
                finish()
                return
            }
        }
        try {
            if (system == "psp") installPspAssets()
            val config = GLRetroViewData(this).apply {
                coreFilePath = core
                gameFilePath = rom.absolutePath
                systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
                savesDirectory = saveDir.absolutePath
                shader = ShaderConfig.Default
                preferLowLatencyAudio = true
                rumbleEventsEnabled = false
                saveRAMState = File(saveDir, "battery.srm").takeIf { it.isFile }?.readBytes()
                // Start with the lowest PSP internal resolution; users can tune later.
                if (system == "psp") variables = arrayOf(
                    Variable("ppsspp_internal_resolution", "480x272"),
                    Variable("ppsspp_rendering_mode", "OpenGL")
                )
            }
            retro = GLRetroView(this, config)
            buildInterface(intent.getStringExtra("gameName") ?: "Bolso Retro")
            // Register exactly once: a configuration change only changes layout params.
            lifecycle.addObserver(retro)
            started = true
            lifecycleScope.launch {
                retro.getGLRetroErrors().collect { code ->
                    Toast.makeText(this@GameActivity,
                        "Emulador: erro $code. Confira a ROM e o núcleo.", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Log.e("BolsoRetro", "Failed to start native player", e)
            Toast.makeText(this, "Falha ao iniciar emulador: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun installPspAssets() {
        val systemDir=File(filesDir,"system")
        val target=File(systemDir,"PPSSPP")
        val marker=File(target,".bolso-installed-v23")
        if (marker.isFile) return
        target.mkdirs()
        assets.open("PPSSPP.zip").use { asset ->
            ZipInputStream(asset).use { zip ->
                var entry=zip.nextEntry
                while (entry!=null) {
                    var relative=entry.name.replace('\\','/')
                    if(relative.startsWith("PPSSPP/"))relative=relative.removePrefix("PPSSPP/")
                    if(relative.isNotEmpty()) {
                        val file=File(target,relative)
                        val safeRoot=target.canonicalPath+File.separator
                        if(!file.canonicalPath.startsWith(safeRoot))throw SecurityException("Caminho inválido no pacote PSP")
                        if(entry.isDirectory)file.mkdirs() else {
                            file.parentFile?.mkdirs()
                            FileOutputStream(file).use { out ->zip.copyTo(out,64*1024) }
                        }
                    }
                    zip.closeEntry()
                    entry=zip.nextEntry
                }
            }
        }
        marker.writeText("PPSSPP system assets installed")
    }

    private fun rounded(color: Int, radius: Int = 13): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), Color.argb(80, 207, 208, 247))
    }

    private fun controlColor(highlight: Boolean): Int = Color.argb(
        (opacity * 255).toInt().coerceIn(0, 255),
        if (highlight) 116 else 37,
        if (highlight) 93 else 46,
        if (highlight) 224 else 70
    )

    private fun refreshTransparency() {
        controlButtons.forEach { (button, highlight) ->
            button.background = rounded(controlColor(highlight), 12)
        }
    }

    private fun label(text: String, size: Float = 12f): TextView = TextView(this).apply {
        this.text = text
        setTextColor(ink)
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun menuButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(ink)
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.argb(175, 30, 39, 67), 9)
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(5), 0, dp(5), 0)
        setOnClickListener { action() }
    }

    private fun keyButton(text: String, key: Int, size: Int, highlight: Boolean = false): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(ink)
            textSize = if (text.length > 3) 9f else 19f
            typeface = Typeface.DEFAULT_BOLD
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            background = rounded(controlColor(highlight), 12)
            controlButtons.add(this to highlight)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            // DOWN/UP must reach Libretro, including long presses.
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> retro.sendKeyEvent(KeyEvent.ACTION_DOWN, key)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> retro.sendKeyEvent(KeyEvent.ACTION_UP, key)
                }
                true
            }
        }

    private fun blank(size: Int): Space = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
    }

    private fun horizontal(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        views.forEach { child ->
            val p = child.layoutParams ?: LinearLayout.LayoutParams(-2, -2)
            addView(child, p)
        }
    }

    /** D-pad stays at the same lower-left coordinates as in 2.1. */
    private fun makeLeft(size: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(horizontal(
            keyButton("↖", KeyEvent.KEYCODE_DPAD_UP_LEFT, size),
            keyButton("↑", KeyEvent.KEYCODE_DPAD_UP, size),
            keyButton("↗", KeyEvent.KEYCODE_DPAD_UP_RIGHT, size)
        ))
        addView(horizontal(
            keyButton("←", KeyEvent.KEYCODE_DPAD_LEFT, size),
            blank(size),
            keyButton("→", KeyEvent.KEYCODE_DPAD_RIGHT, size)
        ))
        addView(horizontal(
            keyButton("↙", KeyEvent.KEYCODE_DPAD_DOWN_LEFT, size),
            keyButton("↓", KeyEvent.KEYCODE_DPAD_DOWN, size),
            keyButton("↘", KeyEvent.KEYCODE_DPAD_DOWN_RIGHT, size)
        ))
    }

    /** The shoulder controls are anchored independently so DS L/R don't move. */
    private fun makeRight(size: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        if (system in setOf("nds", "ps1", "psp", "ps2")) {
            // Keep X/Y compact to leave room for bigger A/B without hitting R.
            val xy = (size - 5).coerceAtLeast(34)
            val ps = system == "ps1" || system == "psp" || system == "ps2"
            addView(horizontal(
                keyButton(if (ps) "△" else "X", KeyEvent.KEYCODE_BUTTON_X, xy, true),
                keyButton(if (ps) "□" else "Y", KeyEvent.KEYCODE_BUTTON_Y, xy, true)
            ))
        }
        val face = size + if (landscape()) 10 else 12
        val ps = system == "ps1" || system == "psp" || system == "ps2"
        addView(horizontal(
            keyButton(if (ps) "✕" else "B", KeyEvent.KEYCODE_BUTTON_B, face, true),
            keyButton(if (ps) "○" else "A", KeyEvent.KEYCODE_BUTTON_A, face, true)
        ))
        if (system == "gba") {
            addView(Space(this@GameActivity), LinearLayout.LayoutParams(1, dp(12)))
        }
        // SELECT and START have exactly the same square size, lower than in 2.1.
        addView(horizontal(
            keyButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT, size),
            keyButton("START", KeyEvent.KEYCODE_BUTTON_START, size)
        ))
    }

    /**
     * GBA-only action buttons: an independently sized ROOT-level overlay.
     *
     * The old nested rightControls panel sometimes disappeared on devices
     * where the GL surface and controller overlay were recomposited during
     * rotation. Creating this panel as a separate root child ensures that
     * A/B and SELECT/START stay above the GL surface. Nintendo DS is not
     * changed by this path.
     */
    private fun placeGbaActions(size: Int, wide: Boolean) {
        gbaActionLayer?.let { root.removeView(it) }
        gbaActionLayer = null
        if (system != "gba") return

        val face = size + if (wide) 10 else 12
        val panelWidth = 2 * (face + 4)
        val panelHeight = face + size + 20
        val layer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            elevation = dp(20).toFloat()
            contentDescription = "Controles GBA: A, B, Select e Start"
        }

        val faceRow = horizontal(
            keyButton("B", KeyEvent.KEYCODE_BUTTON_B, face, true),
            keyButton("A", KeyEvent.KEYCODE_BUTTON_A, face, true)
        )
        layer.addView(faceRow, FrameLayout.LayoutParams(-2, -2,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val systemRow = horizontal(
            keyButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT, size),
            keyButton("START", KeyEvent.KEYCODE_BUTTON_START, size)
        )
        layer.addView(systemRow, FrameLayout.LayoutParams(-2, -2,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        root.addView(layer, FrameLayout.LayoutParams(dp(panelWidth), dp(panelHeight),
            Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = dp(if (wide) 9 else 8)
            bottomMargin = dp(if (wide) 8 else 12)
        })
        layer.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        layer.bringToFront()
        gbaActionLayer = layer
        // Diagnostic information can be inspected via Android logcat.
        layer.post {
            Log.i("BolsoRetro", "GBA action layer: ${layer.width}x${layer.height}, " +
                "A/B and Start/Select visible=${layer.visibility == View.VISIBLE}")
        }
    }

    private fun placeShoulder(label: String, key: Int, size: Int, left: Boolean, bottom: Int) {
        val shoulder = horizontal(keyButton(label, key, size))
        shoulderControls.add(shoulder)
        val baseBottom = bottom + 3 * (size + 4)
        val extraGba = if (system == "gba") 26 else 0
        overlay.addView(shoulder, FrameLayout.LayoutParams(-2, -2,
            (if (left) Gravity.START else Gravity.END) or Gravity.BOTTOM).apply {
            if (left) leftMargin = dp(if (landscape()) 9 else 8)
            else rightMargin = dp(if (landscape()) 9 else 8)
            bottomMargin = dp(baseBottom + extraGba)
        })
    }

    private fun placeExtraShoulder(text: String, key: Int, size: Int, left: Boolean, wide: Boolean) {
        val shoulder=horizontal(keyButton(text,key,size))
        shoulderControls.add(shoulder)
        overlay.addView(shoulder,FrameLayout.LayoutParams(-2,-2,
            (if(left) Gravity.START else Gravity.END) or Gravity.TOP).apply {
            topMargin=dp(if(wide) 51 else 64)
            if(left)leftMargin=dp(8) else rightMargin=dp(8)
        })
    }
    private fun placeAnalogStick(wide: Boolean) {
        val analog = object : View(this) {
            private val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            private var dx=0f
            private var dy=0f
            override fun onDraw(canvas: android.graphics.Canvas) {
                val cx=width/2f; val cy=height/2f; val r=(Math.min(width,height)/2f)*0.88f
                paint.color=Color.argb((opacity*185).toInt(),76,94,137)
                canvas.drawCircle(cx,cy,r,paint)
                paint.color=Color.argb(205,194,196,244)
                canvas.drawCircle(cx+dx*r*0.6f,cy+dy*r*0.6f,r*0.35f,paint)
            }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if(e.actionMasked==MotionEvent.ACTION_DOWN||e.actionMasked==MotionEvent.ACTION_MOVE){
                    val r=Math.min(width,height)/2f
                    dx=((e.x-width/2f)/r).coerceIn(-1f,1f)
                    dy=((e.y-height/2f)/r).coerceIn(-1f,1f)
                } else if(e.actionMasked==MotionEvent.ACTION_UP||e.actionMasked==MotionEvent.ACTION_CANCEL){dx=0f;dy=0f}
                else return true
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT,dx,dy)
                invalidate()
                return true
            }
        }
        shoulderControls.add(analog)
        overlay.addView(analog,FrameLayout.LayoutParams(dp(if(wide) 68 else 76),dp(if(wide) 68 else 76),
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin=dp(if(wide) 12 else 32)
        })
    }

    /** Speed goes 1x -> approx. 1.5x -> 2x -> 5x -> 1x with successive taps. */
    private fun nextSpeed() {
        speedIndex = (speedIndex + 1) % 4
        applySpeed()
    }

    private fun applySpeed() {
        if (!started) return
        speedHandler.removeCallbacks(speedCycle)
        speedAlternate = false
        retro.frameSpeed = when (speedIndex) {
            2 -> 2
            3 -> 5
            else -> 1
        }
        if (speedIndex == 1 && !isFinishing) {
            speedHandler.postDelayed(speedCycle, 120L)
        }
        speedButton.text = when (speedIndex) {
            1 -> "1,5×"
            2 -> "2×"
            3 -> "5×"
            else -> "1×"
        }
        speedButton.contentDescription = "Velocidade ${speedButton.text}. Toque para aumentar"
    }

    private fun buildInterface(title: String) {
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        setContentView(root)
        gameRegion = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(gameRegion, FrameLayout.LayoutParams(dp(240), dp(160), Gravity.TOP or Gravity.START))
        // Retain the GLRetroView and its native core for every orientation/layout change.
        gameRegion.addView(retro, FrameLayout.LayoutParams(-1, -1))

        overlay = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            elevation = dp(3).toFloat()
        }
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            setBackgroundColor(Color.argb(175, 9, 14, 28))
            elevation = dp(8).toFloat()
        }
        root.addView(toolbar, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP))
        // Collapse is distinct from Back: no accidental game exit when hiding the bar.
        toolbar.addView(menuButton("⌃", ::toggleToolbar).apply {
            contentDescription = "Recolher barra de ferramentas"
        }, LinearLayout.LayoutParams(dp(39), dp(38)))
        toolbar.addView(menuButton("‹", ::finish), LinearLayout.LayoutParams(dp(39), dp(38)))
        titleLabel = label(title, 12f)
        toolbar.addView(titleLabel, LinearLayout.LayoutParams(0, dp(38), 1f))
        toolbar.addView(menuButton("Salvar", ::saveState), LinearLayout.LayoutParams(dp(59), dp(38)))
        toolbar.addView(menuButton("Carregar", ::loadState), LinearLayout.LayoutParams(dp(69), dp(38)))
        toolbar.addView(menuButton("◐", {
            opacity = when {
                opacity < .32f -> .45f
                opacity < .58f -> .7f
                else -> .25f
            }
            getPreferences(MODE_PRIVATE).edit().putFloat("controlOpacity", opacity).apply()
            refreshTransparency()
        }), LinearLayout.LayoutParams(dp(39), dp(38)))
        toolbar.addView(menuButton("↶20", ::rewindTwentySeconds).apply {
            contentDescription = "Voltar aproximadamente vinte segundos no jogo"
        }, LinearLayout.LayoutParams(dp(48), dp(38)))
        speedButton = menuButton("1×", ::nextSpeed)
        toolbar.addView(speedButton, LinearLayout.LayoutParams(dp(47), dp(38)))
        toolbar.addView(menuButton("◎", {
            controlsVisible = !controlsVisible
            getPreferences(MODE_PRIVATE).edit().putBoolean("controlsVisible", controlsVisible).apply()
            updateVisibility()
        }), LinearLayout.LayoutParams(dp(39), dp(38)))

        compactMenu = menuButton("☰", ::toggleToolbar).apply {
            contentDescription = "Mostrar barra de ferramentas"
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }
        root.addView(compactMenu, FrameLayout.LayoutParams(dp(39), dp(39), Gravity.TOP or Gravity.START).apply {
            topMargin = dp(5)
            leftMargin = dp(5)
        })
        root.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                updateGameViewport()
            }
        }
        layoutForOrientation()
    }

    private fun toggleToolbar() {
        menuExpanded = !menuExpanded
        toolbar.visibility = if (menuExpanded) View.VISIBLE else View.GONE
        compactMenu.visibility = if (menuExpanded) View.GONE else View.VISIBLE
        // The core stays alive; only the area in which its surface is drawn changes.
        updateGameViewport()
    }

    /**
     * Fit the COMPLETE video image into the genuinely usable area. The old fixed
     * top/bottom margins clipped the DS 256x384 two-screen image on some phones.
     * All dimensions are in screen pixels here, independent of density/orientation.
     */
    private fun updateGameViewport() {
        if (!::root.isInitialized || !::gameRegion.isInitialized || !::leftControls.isInitialized) return
        val w = root.width
        val h = root.height
        if (w < dp(120) || h < dp(120)) return
        val wide = landscape()
        // In portrait DS the small ☰ is at the top-left; leave exactly its
        // height above the picture, so the button never masks screen pixels.
        val menuBottom = when {
            menuExpanded -> dp(51)
            system == "nds" && !wide -> dp(46)
            else -> dp(6)
        }
        val ratio = when (system) {
            "nds" -> 256f / 384f  // Two vertically stacked 256 x 192 DS screens.
            "gba" -> 240f / 160f
            "psp" -> 480f / 272f
            "ps2" -> 4f / 3f
            else -> 4f / 3f
        }
        val left: Int
        val right: Int
        val top: Int
        val bottom: Int
        if (wide) {
            // Dedicated side space for the D-pad and face buttons. Neither can be
            // clipped by the game surface, even on compact landscape phones.
            val pad = if (system == "ps1" || system == "psp" || system == "ps2") 3 * 47 + 27 else 3 * 47 + 15
            val faces = if (system == "gba") 2 * 57 + 17 else 2 * 57 + 19
            left = dp(pad).coerceAtMost(w / 3)
            right = w - dp(faces).coerceAtMost(w / 3)
            top = menuBottom
            bottom = h - dp(7)
        } else {
            left = dp(5)
            right = w - dp(5)
            top = menuBottom
            // Reserve the controls area. The DS bottom screen can approach the
            // top edge of L/R, but it is never allowed to run off the viewport.
            val controlSize = 52
            val shoulderTopFromBottom = (if (system == "gba") 26 else 0) + 13 + 3 * (controlSize + 4) + controlSize + 4
            bottom = if (system == "nds") h - dp(shoulderTopFromBottom - 7)
                else h - dp(3 * (controlSize + 4) + 35)
        }
        val aw = (right - left).coerceAtLeast(dp(40))
        val ah = (bottom - top).coerceAtLeast(dp(40))
        val imageW = minOf(aw, (ah * ratio).toInt()).coerceAtLeast(dp(20))
        val imageH = minOf(ah, (imageW / ratio).toInt()).coerceAtLeast(dp(20))
        val x = left + (aw - imageW) / 2
        // DS top screen begins BELOW the toolbar, without vertically centering
        // any excess room above it. Its lower screen extends toward L/R.
        val y = top + (ah - imageH).coerceAtLeast(0) / 2
        val params = FrameLayout.LayoutParams(imageW, imageH, Gravity.TOP or Gravity.START).apply {
            leftMargin = x
            topMargin = y
        }
        val old = gameRegion.layoutParams as? FrameLayout.LayoutParams
        if (old == null || old.width != params.width || old.height != params.height ||
            old.leftMargin != params.leftMargin || old.topMargin != params.topMargin) {
            gameRegion.layoutParams = params
        }
    }

    /** Rebuild only Android controls, not the GL surface or native core. */
    private fun layoutForOrientation() {
        val wide = landscape()
        applyImmersive(wide)
        val size = if (wide) 43 else 52
        controlButtons.clear()
        shoulderControls.clear()
        overlay.removeAllViews()
        leftControls = makeLeft(size)
        // GBA face buttons no longer use the nested right-side controller group.
        // All other consoles retain the existing (working) layout unchanged.
        rightControls = makeRight(size)
        val margin = dp(if (wide) 9 else 8)
        val bottomControls = if (wide) 1 else 4
        overlay.addView(leftControls, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = margin
            bottomMargin = dp(if (wide) 8 else 13)
        })
        overlay.addView(rightControls, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = margin
            bottomMargin = dp(bottomControls)
        })
        // Explicit elevation prevents GBA A/B/Start/Select disappearing beneath
        // a freshly resized native GL surface after screen rotation.
        leftControls.elevation = dp(4).toFloat()
        rightControls.elevation = dp(4).toFloat()
        placeShoulder("L", KeyEvent.KEYCODE_BUTTON_L1, size, true, if (wide) 8 else 13)
        placeShoulder("R", KeyEvent.KEYCODE_BUTTON_R1, size, false, if (wide) 8 else 13)
        if (system == "ps1" || system == "ps2") {
            placeExtraShoulder("L2", KeyEvent.KEYCODE_BUTTON_L2, size, true, wide)
            placeExtraShoulder("R2", KeyEvent.KEYCODE_BUTTON_R2, size, false, wide)
        }
        if (system == "ps1" || system == "psp" || system == "ps2") placeAnalogStick(wide)
        // A dedicated root-level layer avoids the disappearing GBA controls.
        // GBA face buttons are part of overlay, exactly like the working DS layout.
        gbaActionLayer?.let { root.removeView(it) }
        gbaActionLayer = null
        titleLabel.visibility = if (resources.configuration.screenWidthDp < 500) View.GONE else View.VISIBLE
        // Ensure the extra collapse button never pushes Save/Load off a narrow display.
        val compact = resources.configuration.screenWidthDp < 370
        val widths = if (compact) intArrayOf(28, 28, 46, 54, 30, 40, 39, 30)
            else intArrayOf(39, 39, 59, 69, 39, 48, 47, 39)
        val indices = intArrayOf(0, 1, 3, 4, 5, 6, 7, 8)
        for (i in indices.indices) {
            val child = toolbar.getChildAt(indices[i])
            val lp = child.layoutParams as LinearLayout.LayoutParams
            val newWidth = dp(widths[i])
            if (lp.width != newWidth) { lp.width = newWidth; child.layoutParams = lp }
        }
        updateVisibility()
        root.post { updateGameViewport() }
    }

    private fun applyImmersive(wide: Boolean) {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (wide) {
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else 0
    }

    private fun updateVisibility() {
        val visibility = if (controlsVisible) View.VISIBLE else View.GONE
        leftControls.visibility = visibility
        rightControls.visibility = visibility
        shoulderControls.forEach { it.visibility = visibility }
        gbaActionLayer?.visibility = visibility
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Crucial: neither setContentView() nor GLRetroView creation happens here.
        root.post { layoutForOrientation() }
    }

    private fun saveSram() {
        if (!started) return
        try { File(saveDir, "battery.srm").writeBytes(retro.serializeSRAM()) }
        catch (e: Exception) { Log.w("BolsoRetro", "Could not persist SRAM", e) }
    }
    private fun saveState() {
        if (!started) return
        try {
            File(saveDir, "manual.state").writeBytes(retro.serializeState())
            saveSram()
            Toast.makeText(this, "Estado salvo", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro ao salvar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private fun loadState() {
        if (!started) return
        try {
            val f = File(saveDir, "manual.state")
            if (!f.exists()) { Toast.makeText(this, "Nenhum estado salvo", Toast.LENGTH_SHORT).show(); return }
            val ok = retro.unserializeState(f.readBytes())
            Toast.makeText(this, if (ok) "Estado carregado" else "Estado incompatível", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro ao carregar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    override fun onPause() {
        speedHandler.removeCallbacks(speedCycle)
        rewindHandler.removeCallbacks(rewindTick)
        saveSram()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (started && ::speedButton.isInitialized) applySpeed()
        rewindHandler.removeCallbacks(rewindTick)
        if (started && system in setOf("gba", "nds", "ps1")) rewindHandler.postDelayed(rewindTick, 2500L)
    }

    override fun onDestroy() {
        rewindHandler.removeCallbacks(rewindTick)
        speedHandler.removeCallbacks(speedCycle)
        super.onDestroy()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_DOWN, keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_UP, keyCode)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) {
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD,
                event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y))
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT,
                event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
