/* Transferência LOCAL ROM → Android, sem servidor. Mantém a biblioteca IndexedDB. */
(function () {
  'use strict';
  const CHUNK_SIZE = 48 * 1024;
  let busy = false;
  function toBase64(bytes) {
    let result = '';
    for (let i = 0; i < bytes.length; i += 4096) {
      result += String.fromCharCode.apply(null, bytes.subarray(i, i + 4096));
    }
    return btoa(result);
  }
  async function launch(game) {
    if (busy) throw new Error('Um jogo já está sendo preparado.');
    if (!window.BolsoAndroid) throw new Error('Conexão com Android indisponível.');
    if (!game || !['gba','nds','ps1','psp'].includes(game.system)) throw new Error('Sistema não suportado ou arquivo ausente.');
    if (game.discUri && ['ps1','psp'].includes(game.system)) {
      const status = BolsoAndroid.openDisc(game.discUri, game.system, String(game.id), game.name, game.originalName || game.name);
      if (status !== 'OK') throw new Error(status || 'Não foi possível abrir disco.');
      return;
    }
    if (!game.file || !['gba','nds'].includes(game.system)) throw new Error('Arquivo de ROM indisponível.');
    busy = true;
    const toast = msg => {
      const el = document.querySelector('#toast');
      if (el) { el.textContent = msg; el.classList.add('visible'); }
    };
    try {
      const file = game.file;
      const original = (game.originalName || '').toLowerCase();
      const isZip = original.endsWith('.zip');
      const ext = isZip ? 'zip' : game.system;
      const begin = BolsoAndroid.begin(game.system, String(game.id), game.name, ext, String(file.size));
      if (begin !== 'OK') throw new Error(begin || 'Não foi possível preparar a ROM.');
      for (let offset = 0; offset < file.size; offset += CHUNK_SIZE) {
        const data = new Uint8Array(await file.slice(offset, offset + CHUNK_SIZE).arrayBuffer());
        const status = BolsoAndroid.chunk(toBase64(data));
        if (status !== 'OK') throw new Error(status || 'Falha na transferência local.');
        if (offset % (CHUNK_SIZE * 32) === 0) toast(`Preparando ROM… ${Math.floor(100*offset/file.size)}%`);
      }
      const status = BolsoAndroid.finish();
      if (status !== 'OK') throw new Error(status || 'Erro ao abrir o jogo.');
      toast('Abrindo emulador nativo…');
    } catch (err) {
      try { BolsoAndroid.cancel(); } catch (_) {}
      throw err;
    } finally { busy = false; }
  }
  window.BolsoNativeGame = Object.freeze({launch});
})();
