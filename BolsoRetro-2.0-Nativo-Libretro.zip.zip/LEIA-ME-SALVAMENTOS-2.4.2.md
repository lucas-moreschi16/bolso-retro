# Bolso Retro 2.4.2 — Histórico e proteção dos salvamentos

## O problema corrigido

As versões anteriores usavam `files/saves/<id>/manual.state` como um **único** slot e o sobrescreviam ao tocar em **Salvar**. Esta atualização não substitui mais aquele arquivo. Se ele já foi sobrescrito, seu conteúdo anterior não pode ser reconstruído a partir deste código.

## Como funciona agora

- **Salvar:** pede confirmação e cria um NOVO arquivo imutável com data, hora e identificador aleatório em `files/saves/<id>/historico/`. Nunca apaga salvamentos manuais.
- **Carregar:** exibe todos os salvamentos manuais, automáticos, o `manual.state` antigo (se existir) e os pontos de segurança feitos antes de carregamentos anteriores. Exibe data, hora e tamanho.
- **Antes de carregar outro estado:** cria automaticamente um novo arquivo `antes-de-carregar`, protegendo a sessão que estava aberta. Se não conseguir criar essa cópia, a restauração é bloqueada.
- **Salvamento automático:** a cada cinco minutos com o jogo em execução, em GBA/DS/PS1. Mantém até 24 estados automáticos, dentro de aproximadamente 256 MB (mínimo de três). Os salvamentos manuais nunca são apagados por esse mecanismo. PSP/PS2 não têm autosave nesta versão por limitações ainda não validadas.
- **Gravação interna dos jogos:** `battery.srm` é preservado em `historico-bateria/` antes de qualquer alteração, protegendo até as alterações feitas no menu de salvamento do próprio jogo. Essas cópias não são apagadas automaticamente.
- **Exportar backup ZIP:** dentro do menu Carregar, exporta todos os arquivos do diretório de salvamentos daquele jogo para um local escolhido no Android. A importação desse ZIP ainda não está disponível na interface; preserve-o para recuperação futura.

## Antes de atualizar o aplicativo

**Não desinstale ou limpe os dados do Bolso Retro.** O Android apaga `files/saves/` quando o aplicativo é desinstalado. Se o APK novo tiver assinatura incompatível, NÃO desinstale o anterior para forçar a instalação. O mecanismo de exportação está disponível somente depois que a nova versão estiver instalada.

**Para tentar recuperar o progresso perdido agora:** se você usou **Salvar** no menu de dentro do Pokémon, abra o mesmo jogo e, na tela inicial, escolha **Continue/Continuar**, sem usar **Carregar** na barra do Bolso Retro. Essa gravação interna pode sobreviver mesmo que `manual.state` tenha sido sobrescrito. Caso o progresso existisse apenas no estado manual antigo, não há garantia de recuperação retroativa.

## Instalação no GitHub

Faça o upload deste ZIP com o nome **exato** `BolsoRetro-2.0-Nativo-Libretro.zip` na raiz do ramo `lucas-moreschi16-patch-1`, substituindo a versão anterior. O workflow já existente lê este arquivo, extrai o projeto e compila o APK. Não envie um arquivo com `.zip.zip`.

## Escopo e validação

- Mantém os núcleos e os controles GBA/DS existentes, a biblioteca e a identidade Pokémon.
- Alterado `app/src/main/java/br/com/bolsoretro/GameActivity.kt` e número de versão.
- Testes estáticos de regressão passam, assim como sintaxe do JavaScript. **Não foi possível executar compilação Android e teste no aparelho neste ambiente**; use GitHub Actions e teste especialmente as opções de salvamento e restauração antes de confiar nelas como única cópia.
- Salvamentos em disco requerem espaço disponível. Não são sincronizados automaticamente com a nuvem.
