#!/usr/bin/env bash
set -euo pipefail
# Lemuroid também usa núcleos Libretro compilados para Android. Downloads sem ROMs.
BASE="https://buildbot.libretro.com/nightly/android/latest/arm64-v8a"
DEST="app/src/main/jniLibs/arm64-v8a"
mkdir -p "$DEST"
for core in mgba melondsds; do
  archive="${core}_libretro_android.so.zip"
  echo "Obtendo núcleo nativo: $core"
  curl --fail --location --retry 4 --retry-delay 3 --connect-timeout 30 --silent --show-error "$BASE/$archive" -o "/tmp/$archive"
  unzip -o -q "/tmp/$archive" -d "$DEST"
  test -s "$DEST/${core}_libretro_android.so"
  mv -f "$DEST/${core}_libretro_android.so" "$DEST/lib${core}_libretro_android.so"
  file "$DEST/lib${core}_libretro_android.so"
  rm -f "/tmp/$archive"
done
