# Bolso Retro 2.2 — Layout e aceleração

Mudanças aplicadas sobre 2.1, preservando a atividade nativa e a rotação sem reiniciar:

* Nos jogos GBA, L e R foram elevados mais 26 dp. No Nintendo DS, L e R mantêm suas posições da versão 2.1.
* A e B foram ampliados 10 dp na horizontal / 12 dp na vertical, para GBA e DS.
* SELECT e START permanecem com dimensões idênticas entre si e foram posicionados mais abaixo.
* Nintendo DS: a região do jogo foi deslocada para baixo para proteger a tela superior do recorte pela barra. A tela inferior pode se aproximar dos ombros L e R.
* Botão de velocidade na barra, com ciclo a cada toque: 1× -> ~1,5× -> 2× -> 5× -> 1×.
* Como a API de LibretroDroid aceita somente velocidade inteira, o modo ~1,5× alterna 1 e 2 em intervalos curtos. Essa é uma aproximação, não um multiplicador exato.
* O botão de ocultar os controles agora também esconde L e R.

O núcleo mGBA / melonDS, packageId br.com.bolsoretro, bibliotecas e diretórios de salvamento não foram modificados.


# Bolso Retro 2.1 – Controles transparentes e rotação sem reinício

## Atualização sobre a versão 2.0 (GBA + Nintendo DS)

- O mesmo motor **LibretroDroid** continua executando GBA (mGBA) e DS (melonDS DS).
- Em paisagem (horizontal), a **GLRetroView ocupa a tela toda**. O controle deixa de reservar uma faixa opaca e passa a flutuar nas bordas.
- Os botões ficam semitransparentes, mantendo as letras legíveis. `◐` alterna a transparência entre 25%, 45% e 70%. `◎` mostra/oculta os controles.
- Em retrato (vertical), o espaço inferior é reservado para comandos e a parte superior mantém o jogo livre.
- Ao girar o celular, `GameActivity` usa `android:configChanges` e reconfigura **somente os controles**; o GLRetroView, a ROM e o estado do núcleo permanecem vivos.
- Salvamentos de SRAM e estados manuais utilizam os mesmos diretórios privados da versão 2.0, se o sistema permitir atualizar o APK sem desinstalar.

## Atualização do projeto do GitHub com apenas um arquivo

O workflow que já foi instalado no repositório usa literalmente este nome de ZIP:

`BolsoRetro-2.0-Nativo-Libretro.zip`

Envie **este ZIP inteiro** à raiz da branch `lucas-moreschi16-patch-1`, substituindo o arquivo anterior de mesmo nome. **Não extraia o ZIP** ao subir ao GitHub e **não altere o YAML**, pois ele continua apontando para esse nome. Ao efetuar o commit, o `push` deve iniciar nova execução no GitHub Actions.

**Nota:** O artefato da execução será chamado `BolsoRetro-Nativo-2.0` porque esse nome está fixado no workflow antigo; o código atualizado tem `versionCode 4` / `versionName 2.1.0-native-beta`.

## Limitações e segurança dos dados

O projeto foi validado estruturalmente, mas esta correção ainda **não foi compilada e testada em um aparelho Android**. A rotação deve preservar o núcleo, porém um encerramento pelo sistema operacional pode interromper a partida. Salve regularmente.

**Não desinstale a versão antiga sem backup dos salvamentos!** Versões debug compiladas em execuções diferentes do GitHub podem usar assinaturas diferentes e, nesse caso, o Android recusará atualizar por cima. Desinstalar apaga o banco IndexedDB e os saves privados. Não distribuímos ROMs, BIOS ou jogos comerciais.

Licenças de terceiros e atribuições permanecem em `THIRD_PARTY.md` e `LICENSE-GPL-3.0.txt`.

# Bolso Retro 2.0 — execução nativa Libretro (alpha)

Esta versão substitui **EmulatorJS + WebView na execução** por **LibretroDroid + GLRetroView**, usando mGBA para Game Boy Advance e melonDS DS para Nintendo DS. A interface de biblioteca continua WebView + IndexedDB, preservando a estrutura visual do projeto anterior. Não há ROMs incluídas.

## Arquitetura

1. A biblioteca mostra os jogos gravados no IndexedDB do app (a mesma origem do APK anterior).
2. `app.js` envia o jogo para `native-bridge.js`, que lê o Blob em fatias (48 KiB) e as transfere via interface JavaScript local.
3. `MainActivity.java` recebe e grava a ROM na área privada do Android; se ZIP, extrai a ROM compatível com limite de tamanho.
4. `GameActivity.kt` recebe o caminho da ROM, prepara `GLRetroViewData` e inicia `GLRetroView` (renderização e áudio nativos).
5. Botões de toque e gamepads físicos geram eventos Libretro. No DS, o toque na tela da GLRetroView é encaminhado ao núcleo.
6. Estados salvos manualmente e SRAM ficam em `files/saves/` com identificadores distintos para cada jogo.

## Compilar no GitHub Actions

- Extraia **este projeto completo** e faça commit preservando as pastas (`app/`, `scripts/`, `.github/workflows/`). Não envie somente o ZIP esperando que o GitHub o extraia.
- A compilação usa JDK 17, Gradle 8.9, LibretroDroid via JitPack e núcleos Android ARM64 do buildbot Libretro.
- Os downloads de dependências e núcleos exigem internet **somente para a compilação**.
- A versão alvo é **Android ARM64**; aparelhos ARM32 não são suportados nesta alpha.
- Confira o artefato **BolsoRetro-Nativo-2.0** em Actions após compilação verde.

### Se o GitHub receber todos os arquivos na raiz

O upload pelo navegador às vezes perde pastas. Recomenda-se extrair localmente e fazer `git add -A`, `git commit`, `git push` com Git instalado. O workflow precisa estar em `.github/workflows/build-apk.yml` e a classe nativa em `app/src/main/java/br/com/bolsoretro/GameActivity.kt`.

## Limitações e testes obrigatórios

- **Ainda não foi compilado nem validado em aparelho físico neste ambiente**. Esta é uma integração de código cuja versão Android precisa ser compilada e testada no GitHub antes de se declarar funcional.
- A dependência JitPack e os endereços dos núcleos podem mudar; CI falhará explicitamente se indisponíveis.
- O núcleo melonDS DS pode exigir firmware/BIOS legalmente obtidos para certos jogos, e suporte a dual screen depende das opções do núcleo. Verifique especificamente *Pokémon HeartGold*.
- Salvamentos do EmulatorJS não são automaticamente convertidos para estados/arquivos Libretro.
- Esta versão mantém o mesmo applicationId `br.com.bolsoretro`, mas compilação com chave debug diferente pode impedir instalar sobre o APK anterior. Faça backup das ROMs/saves antes de desinstalar.
- Bluetooth é encaminhado para LibretroDroid, ainda não testado em dispositivo.
- Núcleos instalados no APK; não requer CDN ou internet para carregar a ROM após instalado.

## Licenças

O LibretroDroid e Lemuroid usam **GPL-3.0**, portanto qualquer redistribuição com componentes GPL deve preservar licenças, atribuição e acesso ao código-fonte correspondente. Veja `THIRD_PARTY.md` e `LICENSE-GPL-3.0.txt`. Esta adaptação utiliza LibretroDroid como dependência; não é um clone literal do código do Lemuroid.
