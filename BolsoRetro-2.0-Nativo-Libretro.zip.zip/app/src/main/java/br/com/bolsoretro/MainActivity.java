package br.com.bolsoretro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int PICK = 19;
    private static final long MAX_ROM = 512L * 1024 * 1024;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private final Object transferLock = new Object();
    private ValueCallback<Uri[]> fileCallback;
    private WebView browser;
    private File tmp;
    private FileOutputStream pending;
    private long count;
    private long expected;
    private String coreSystem;
    private String safeID;
    private String gameName;
    private String extension;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,16,29));
        getWindow().setNavigationBarColor(Color.rgb(10,16,29));
        browser = new WebView(this);
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest r) {
                return assetLoader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                return !APP_ORIGIN.equals(u.getScheme()+"://"+u.getHost());
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                   FileChooserParams params) {
                if(fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try {startActivityForResult(pick,PICK);return true;}
                catch(Exception ex) {fileCallback=null;callback.onReceiveValue(null);return false;}
            }
        });
        browser.addJavascriptInterface(new Bridge(),"BolsoAndroid");
        setContentView(browser);
        browser.loadUrl(APP_ORIGIN + "/assets/index.html");
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req != PICK || fileCallback == null) return;
        Uri[] uris=null;
        if(result == RESULT_OK && data != null) {
            if(data.getClipData()!=null) {
                int n=data.getClipData().getItemCount(); uris=new Uri[n];
                for(int i=0;i<n;i++) uris[i]=data.getClipData().getItemAt(i).getUri();
            } else if(data.getData()!=null) uris=new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(uris); fileCallback=null;
    }
    private void abortTransfer() {
        try {if(pending!=null)pending.close();}catch(Exception ignore){}
        pending=null;
        if(tmp!=null)tmp.delete();
        tmp=null;count=0;expected=0;
    }
    private static String shortHash(String s) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
        StringBuilder out=new StringBuilder();
        for(int i=0;i<8;i++)out.append(String.format(Locale.US,"%02x",digest[i]&255));
        return out.toString();
    }
    public class Bridge {
        @JavascriptInterface public String begin(String system,String id,String title,String ext,String length) {
            synchronized(transferLock) {
                abortTransfer();
                if(!("gba".equals(system)||"nds".equals(system)))return "Sistema não suportado";
                if(!("gba".equals(ext)||"nds".equals(ext)||"zip".equals(ext)))return "Formato inválido";
                try {
                    long size=Long.parseLong(length);
                    if(size<=0||size>MAX_ROM)return "ROM acima do limite de 512 MB";
                    String safe = shortHash(system+"/"+id+"/"+title);
                    File directory = new File(getCacheDir(),"import");
                    if(!directory.exists()&&!directory.mkdirs())return "Falha ao preparar diretório";
                    tmp=new File(directory,safe+".part");
                    pending=new FileOutputStream(tmp,false);
                    expected=size;count=0;coreSystem=system;extension=ext;safeID=safe;gameName=title;
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Falha: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String chunk(String encoded) {
            synchronized(transferLock) {
                if(pending==null)return "Transferência não iniciada";
                try {
                    byte[] buf=Base64.decode(encoded,Base64.NO_WRAP);
                    if(count+buf.length>expected)throw new IOException("ROM maior que o informado");
                    pending.write(buf);count+=buf.length;
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Falha na transferência: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String finish() {
            synchronized(transferLock) {
                if(pending==null||count!=expected)return "ROM incompleta";
                try {
                    pending.close();pending=null;
                    File rom=new File(getCacheDir(),"bolso-game-"+safeID+"."+coreSystem);
                    if("zip".equals(extension)) {
                        try(ZipInputStream zip=new ZipInputStream(new FileInputStream(tmp));
                            FileOutputStream output=new FileOutputStream(rom,false)) {
                            ZipEntry z;boolean found=false;
                            while((z=zip.getNextEntry())!=null) {
                                if(z.isDirectory()||!z.getName().toLowerCase(Locale.US).endsWith("."+coreSystem))continue;
                                byte[] buff=new byte[65536];int n;long extracted=0;
                                while((n=zip.read(buff))!=-1) {
                                    extracted+=n;
                                    if(extracted>MAX_ROM)throw new IOException("ROM descompactada acima de 512 MB");
                                    output.write(buff,0,n);
                                }
                                found=true;break;
                            }
                            if(!found)throw new IOException("ZIP sem ROM ."+coreSystem);
                        }
                        tmp.delete();
                    } else {
                        if(!tmp.renameTo(rom))Files.copy(tmp.toPath(),rom.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        tmp.delete();
                    }
                    if(!rom.exists()||rom.length()==0)throw new IOException("Arquivo vazio");
                    String sys=coreSystem, title=gameName, saveId=safeID;
                    tmp=null;
                    runOnUiThread(()->{
                        Intent intent=new Intent(MainActivity.this,GameActivity.class);
                        intent.putExtra("rom",rom.getAbsolutePath());intent.putExtra("system",sys);
                        intent.putExtra("gameName",title);intent.putExtra("saveId",saveId);
                        startActivity(intent);
                    });
                    return "OK";
                } catch(Exception e) {abortTransfer();return "Não foi possível abrir ROM: "+e.getMessage();}
            }
        }
        @JavascriptInterface public void cancel(){synchronized(transferLock){abortTransfer();}}
    }
    @Override protected void onDestroy(){
        synchronized(transferLock){abortTransfer();}
        if(browser!=null)browser.destroy();
        super.onDestroy();
    }
}
