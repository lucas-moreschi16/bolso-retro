/*
 * Bolso Retro - Android native Libretro player.
 * The LibretroDroid dependency is provided by its authors under GPL-3.0.
 * Copyright (C) 2026 Bolso Retro contributors. SPDX-License-Identifier: GPL-3.0-or-later
 */
package br.com.bolsoretro

import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File

/**
 * Changes in orientation are handled inside this same Activity instance.
 * The GLRetroView and its loaded Libretro core are never removed/recreated on rotation.
 */
class GameActivity : ComponentActivity() {
    private lateinit var retro: GLRetroView
    private lateinit var saveDir: File
    private lateinit var system: String
    private lateinit var root: FrameLayout
    private lateinit var gameRegion: FrameLayout
    private lateinit var overlay: FrameLayout
    private lateinit var leftControls: LinearLayout
    private lateinit var rightControls: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var speedButton: Button
    private lateinit var titleLabel: TextView
    private var speedIndex = 0
    private var speedAlternate = false
    private val speedHandler = Handler(Looper.getMainLooper())
    private val speedCycle = object : Runnable {
        override fun run() {
            if (!started || speedIndex != 1) return
            // LibretroDroid supports integral frameSpeed values. Alternating 1 and 2
            // approximates 1.5x without patching its GPL native library.
            speedAlternate = !speedAlternate
            retro.frameSpeed = if (speedAlternate) 2 else 1
            speedHandler.postDelayed(this, 120L)
        }
    }
    private var started = false
    private var controlsVisible = true
    private var opacity = 0.42f
    private val controlButtons = mutableListOf<Pair<Button, Boolean>>()
    private val shoulderControls = mutableListOf<View>()
    private val bg = Color.rgb(7, 11, 20)
    private val ink = Color.rgb(247, 248, 255)
    private val accent = Color.rgb(132, 116, 245)

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + .5f).toInt()
    private fun landscape() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        system = intent.getStringExtra("system") ?: ""
        val rom = intent.getStringExtra("rom")?.let(::File)
        if (system !in setOf("gba", "nds") || rom == null || !rom.isFile || rom.length() <= 0) {
            Toast.makeText(this, "ROM inválida ou ausente", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        opacity = getPreferences(MODE_PRIVATE).getFloat("controlOpacity", .42f).coerceIn(.22f, .85f)
        controlsVisible = getPreferences(MODE_PRIVATE).getBoolean("controlsVisible", true)
        saveDir = File(filesDir, "saves/${intent.getStringExtra("saveId") ?: "sem-id"}").apply { mkdirs() }
        val core = if (system == "gba") "libmgba_libretro_android.so" else "libmelondsds_libretro_android.so"
        try {
            val config = GLRetroViewData(this).apply {
                coreFilePath = core
                gameFilePath = rom.absolutePath
                systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
                savesDirectory = saveDir.absolutePath
                shader = ShaderConfig.Default
                preferLowLatencyAudio = true
                rumbleEventsEnabled = false
                saveRAMState = File(saveDir, "battery.srm").takeIf { it.isFile }?.readBytes()
            }
            retro = GLRetroView(this, config)
            buildInterface(intent.getStringExtra("gameName") ?: "Bolso Retro")
            // Register exactly once: a configuration change only changes layout params.
            lifecycle.addObserver(retro)
            started = true
            lifecycleScope.launch {
                retro.getGLRetroErrors().collect { code ->
                    Toast.makeText(this@GameActivity,
                        "Emulador: erro $code. Confira a ROM e o núcleo.", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Log.e("BolsoRetro", "Failed to start native player", e)
            Toast.makeText(this, "Falha ao iniciar emulador: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun rounded(color: Int, radius: Int = 13): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), Color.argb(80, 207, 208, 247))
    }

    private fun controlColor(highlight: Boolean): Int = Color.argb(
        (opacity * 255).toInt().coerceIn(0, 255),
        if (highlight) 116 else 37,
        if (highlight) 93 else 46,
        if (highlight) 224 else 70
    )

    private fun refreshTransparency() {
        controlButtons.forEach { (button, highlight) ->
            button.background = rounded(controlColor(highlight), 12)
        }
    }

    private fun label(text: String, size: Float = 12f): TextView = TextView(this).apply {
        this.text = text
        setTextColor(ink)
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun menuButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(ink)
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.argb(155, 30, 39, 67), 9)
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(5), 0, dp(5), 0)
        setOnClickListener { action() }
    }

    private fun keyButton(text: String, key: Int, size: Int, highlight: Boolean = false): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(ink)
            textSize = if (text.length > 3) 9f else 19f
            typeface = Typeface.DEFAULT_BOLD
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            background = rounded(controlColor(highlight), 12)
            controlButtons.add(this to highlight)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            // DOWN/UP must reach Libretro, including long presses.
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> retro.sendKeyEvent(KeyEvent.ACTION_DOWN, key)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> retro.sendKeyEvent(KeyEvent.ACTION_UP, key)
                }
                true
            }
        }

    private fun blank(size: Int): Space = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
    }

    private fun horizontal(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        views.forEach { child ->
            val p = child.layoutParams ?: LinearLayout.LayoutParams(-2, -2)
            addView(child, p)
        }
    }

    /** D-pad stays at the same lower-left coordinates as in 2.1. */
    private fun makeLeft(size: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(horizontal(
            keyButton("↖", KeyEvent.KEYCODE_DPAD_UP_LEFT, size),
            keyButton("↑", KeyEvent.KEYCODE_DPAD_UP, size),
            keyButton("↗", KeyEvent.KEYCODE_DPAD_UP_RIGHT, size)
        ))
        addView(horizontal(
            keyButton("←", KeyEvent.KEYCODE_DPAD_LEFT, size),
            blank(size),
            keyButton("→", KeyEvent.KEYCODE_DPAD_RIGHT, size)
        ))
        addView(horizontal(
            keyButton("↙", KeyEvent.KEYCODE_DPAD_DOWN_LEFT, size),
            keyButton("↓", KeyEvent.KEYCODE_DPAD_DOWN, size),
            keyButton("↘", KeyEvent.KEYCODE_DPAD_DOWN_RIGHT, size)
        ))
    }

    /** The shoulder controls are anchored independently so DS L/R don't move. */
    private fun makeRight(size: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        if (system == "nds") {
            // Keep X/Y compact to leave room for bigger A/B without hitting R.
            val xy = (size - 5).coerceAtLeast(34)
            addView(horizontal(
                keyButton("X", KeyEvent.KEYCODE_BUTTON_X, xy, true),
                keyButton("Y", KeyEvent.KEYCODE_BUTTON_Y, xy, true)
            ))
        }
        val face = size + if (landscape()) 10 else 12
        addView(horizontal(
            keyButton("B", KeyEvent.KEYCODE_BUTTON_B, face, true),
            keyButton("A", KeyEvent.KEYCODE_BUTTON_A, face, true)
        ))
        if (system == "gba") {
            addView(Space(this@GameActivity), LinearLayout.LayoutParams(1, dp(12)))
        }
        // SELECT and START have exactly the same square size, lower than in 2.1.
        addView(horizontal(
            keyButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT, size),
            keyButton("START", KeyEvent.KEYCODE_BUTTON_START, size)
        ))
    }

    private fun placeShoulder(label: String, key: Int, size: Int, left: Boolean, bottom: Int) {
        val shoulder = horizontal(keyButton(label, key, size))
        shoulderControls.add(shoulder)
        val baseBottom = bottom + 3 * (size + 4)
        val extraGba = if (system == "gba") 26 else 0
        overlay.addView(shoulder, FrameLayout.LayoutParams(-2, -2,
            (if (left) Gravity.START else Gravity.END) or Gravity.BOTTOM).apply {
            if (left) leftMargin = dp(if (landscape()) 9 else 8)
            else rightMargin = dp(if (landscape()) 9 else 8)
            bottomMargin = dp(baseBottom + extraGba)
        })
    }

    /** Speed goes 1x -> approx. 1.5x -> 2x -> 5x -> 1x with successive taps. */
    private fun nextSpeed() {
        speedIndex = (speedIndex + 1) % 4
        applySpeed()
    }

    private fun applySpeed() {
        if (!started) return
        speedHandler.removeCallbacks(speedCycle)
        speedAlternate = false
        retro.frameSpeed = when (speedIndex) {
            2 -> 2
            3 -> 5
            else -> 1
        }
        if (speedIndex == 1 && !isFinishing) {
            speedHandler.postDelayed(speedCycle, 120L)
        }
        speedButton.text = when (speedIndex) {
            1 -> "1,5×"
            2 -> "2×"
            3 -> "5×"
            else -> "1×"
        }
        speedButton.contentDescription = "Velocidade ${speedButton.text}. Toque para aumentar"
    }

    private fun buildInterface(title: String) {
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        setContentView(root)
        gameRegion = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(gameRegion, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        gameRegion.addView(retro, FrameLayout.LayoutParams(-1, -1))

        // No opaque panels or fixed-height gamepad area. Overlay uses the free edges.
        overlay = FrameLayout(this)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            setBackgroundColor(Color.argb(95, 9, 14, 28))
        }
        root.addView(toolbar, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP))
        toolbar.addView(menuButton("‹", ::finish), LinearLayout.LayoutParams(dp(42), dp(38)))
        titleLabel = label(title, 12f)
        toolbar.addView(titleLabel, LinearLayout.LayoutParams(0, dp(38), 1f))
        toolbar.addView(menuButton("Salvar", ::saveState), LinearLayout.LayoutParams(dp(59), dp(38)))
        toolbar.addView(menuButton("Carregar", ::loadState), LinearLayout.LayoutParams(dp(69), dp(38)))
        toolbar.addView(menuButton("◐", {
            opacity = when {
                opacity < .32f -> .45f
                opacity < .58f -> .7f
                else -> .25f
            }
            getPreferences(MODE_PRIVATE).edit().putFloat("controlOpacity", opacity).apply()
            refreshTransparency()
        }), LinearLayout.LayoutParams(dp(39), dp(38)))
        speedButton = menuButton("1×", ::nextSpeed)
        toolbar.addView(speedButton, LinearLayout.LayoutParams(dp(47), dp(38)))
        toolbar.addView(menuButton("◎", {
            controlsVisible = !controlsVisible
            getPreferences(MODE_PRIVATE).edit().putBoolean("controlsVisible", controlsVisible).apply()
            updateVisibility()
        }), LinearLayout.LayoutParams(dp(39), dp(38)))
        layoutForOrientation()
    }

    /** Only rebuild the overlay, never recreate the GLRetroView or Libretro core. */
    private fun layoutForOrientation() {
        val wide = landscape()
        applyImmersive(wide)
        val size = if (wide) 43 else 52
        controlButtons.clear()
        shoulderControls.clear()
        overlay.removeAllViews()
        leftControls = makeLeft(size)
        rightControls = makeRight(size)

        val margin = dp(if (wide) 9 else 8)
        // START and SELECT sit lower; the DS shoulders retain 2.1 positions.
        val bottomControls = if (wide) 1 else 4
        overlay.addView(leftControls, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = margin
            bottomMargin = dp(if (wide) 8 else 13)
        })
        overlay.addView(rightControls, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = margin
            bottomMargin = dp(bottomControls)
        })
        placeShoulder("L", KeyEvent.KEYCODE_BUTTON_L1, size, true, if (wide) 8 else 13)
        placeShoulder("R", KeyEvent.KEYCODE_BUTTON_R1, size, false, if (wide) 8 else 13)

        // The upper DS screen was obscured by the toolbar. Shift the two-screen
        // image downward while allowing its lower edge to approach L/R.
        val top = when {
            system == "nds" && wide -> 49
            system == "nds" -> 75
            wide -> 0
            else -> 47
        }
        val bottom = when {
            system == "nds" && wide -> 0
            system == "nds" -> 211
            wide -> 0
            else -> 205
        }
        gameRegion.layoutParams = FrameLayout.LayoutParams(-1, -1, Gravity.CENTER).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }
        // Keep the speed menu usable on narrow phones without clipping buttons.
        titleLabel.visibility = if (resources.configuration.screenWidthDp < 500) View.GONE else View.VISIBLE
        updateVisibility()
    }

    private fun applyImmersive(wide: Boolean) {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (wide) {
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else 0
    }

    private fun updateVisibility() {
        val visibility = if (controlsVisible) View.VISIBLE else View.GONE
        leftControls.visibility = visibility
        rightControls.visibility = visibility
        shoulderControls.forEach { it.visibility = visibility }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Crucial: neither setContentView() nor GLRetroView creation happens here.
        root.post { layoutForOrientation() }
    }

    private fun saveSram() {
        if (!started) return
        try { File(saveDir, "battery.srm").writeBytes(retro.serializeSRAM()) }
        catch (e: Exception) { Log.w("BolsoRetro", "Could not persist SRAM", e) }
    }
    private fun saveState() {
        if (!started) return
        try {
            File(saveDir, "manual.state").writeBytes(retro.serializeState())
            saveSram()
            Toast.makeText(this, "Estado salvo", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro ao salvar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private fun loadState() {
        if (!started) return
        try {
            val f = File(saveDir, "manual.state")
            if (!f.exists()) { Toast.makeText(this, "Nenhum estado salvo", Toast.LENGTH_SHORT).show(); return }
            val ok = retro.unserializeState(f.readBytes())
            Toast.makeText(this, if (ok) "Estado carregado" else "Estado incompatível", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro ao carregar: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    override fun onPause() {
        speedHandler.removeCallbacks(speedCycle)
        saveSram()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (started && ::speedButton.isInitialized) applySpeed()
    }

    override fun onDestroy() {
        speedHandler.removeCallbacks(speedCycle)
        super.onDestroy()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_DOWN, keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) {
            retro.sendKeyEvent(KeyEvent.ACTION_UP, keyCode)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (started && event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) {
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD,
                event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y))
            retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT,
                event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
