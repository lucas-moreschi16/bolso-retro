"""Regressões estáticas: salvar jamais deve apagar o último estado manual."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
s = (root / 'app/src/main/java/br/com/bolsoretro/GameActivity.kt').read_text()

def section(name):
    m = re.search(r"    private fun " + name + r"\(", s)
    assert m, name
    next_m = re.search(r"\n    (?:private |override |public )?fun [a-zA-Z]", s[m.end():])
    return s[m.start():m.end()+next_m.start()] if next_m else s[m.start():]

assert 'manual.state").writeBytes' not in s
assert 'manual.state' in section('storedStates')
assert 'UUID.randomUUID()' in section('createStoredState')
assert 'writeAtomically(destination, bytes)' in section('createStoredState')
assert 'createStoredState("manual",' not in section('saveState')  # confirmation first
assert 'captureNewState("manual", true)' in section('saveState')
assert 'setItems(history.map(::describeState).toTypedArray())' in section('loadState')
assert 'createStoredState("antes-de-carregar", retro.serializeState())' in section('restorePreviousState')
assert '"historico-bateria"' in section('saveSram')
assert 'writeAtomically(backup, current.readBytes())' in section('saveSram')
assert 'writeAtomically(current, bytes)' in section('saveSram')
assert 'exportBackup.launch(' in section('loadState')
assert 'ActivityResultContracts.CreateDocument' in s
assert 'autoSaveHandler.postDelayed(autoSaveTick, autosaveInterval)' in s
assert 'autosaveInterval = 5 * 60 * 1000L' in s
assert 'autos.size > 24' in s
assert 'if (kind == "automatico") trimAutoStates(history)' in s
assert 'if (kind == "manual") trimAutoStates' not in s
print('PASS: manual saves immutable, legacy visible, SRAM previous backed up, autosave rotated, load rollback, ZIP export.')
