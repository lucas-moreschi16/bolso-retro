"""Static regression assertions for the GBA-only control overlay.

This is not a device/render test; it prevents accidentally omitting the
placeGbaActions call again, which caused the buttons to disappear in 2.4.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
s = (root / 'app/src/main/java/br/com/bolsoretro/GameActivity.kt').read_text()

def function_body(name):
    # The Kotlin method may contain nested blocks; limit until the next method.
    m = re.search(r'    private fun '+name+r'\([^\n]*\)[^\n]*\{', s)
    assert m, f'missing method: {name}'
    following = re.search(r'\n    (?:private |override |public )?fun \w+\(', s[m.end():])
    return s[m.start():m.end()+following.start()] if following else s[m.start():]

layout = function_body('layoutForOrientation')
place = function_body('placeGbaActions')
assert 'placeGbaActions(size, wide)' in layout, 'GBA panel not placed in layout'
assert 'if (system == "gba") LinearLayout(this) else makeRight(size)' in layout, 'GBA face buttons are duplicated in nested layout'
assert 'root.addView(layer' in place, 'GBA face buttons not attached at root level'
assert 'layer.bringToFront()' in place
for value in ['KEYCODE_BUTTON_A','KEYCODE_BUTTON_B','KEYCODE_BUTTON_START','KEYCODE_BUTTON_SELECT']:
    assert value in place, f'missing GBA input: {value}'
assert 'rightControls = if (system == "gba")' in layout
assert 'retro = GLRetroView(this, config)' in s
assert 'root.post { layoutForOrientation() }' in s, 'missing layout rebuild after rotation'
print('PASS: GBA controls are instantiated, mounted above game surface and rebuilt after rotation.')
